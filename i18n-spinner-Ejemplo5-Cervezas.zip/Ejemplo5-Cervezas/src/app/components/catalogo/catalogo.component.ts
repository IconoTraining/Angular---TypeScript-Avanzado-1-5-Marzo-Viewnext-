import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Cerveza } from 'src/app/models/Cerveza';
import { NegocioService } from 'src/app/services/negocio.service';

@Component({
  selector: 'app-catalogo',
  templateUrl: './catalogo.component.html',
  styleUrls: ['./catalogo.component.css']
})
export class CatalogoComponent implements OnInit, AfterViewInit {

  cervezas: Cerveza[] = [];

  nombreColumnas=['id','marca','precio','ibu','existencias'];
  dataSource = new MatTableDataSource(this.cervezas);

  // Variable para controlar si se muestra el spinner o no.
  mostrar: boolean = true;

  @ViewChild(MatSort,{static:false})
  sort: MatSort;

  @ViewChild(MatPaginator,{static:false})
  paginator: MatPaginator;

  constructor(private negocioService: NegocioService) {}

  filtrar(dato:string){
    this.dataSource.filter = dato;
  }

  ngAfterViewInit(){
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }

  ngOnInit(): void {

    setTimeout( () => {
      this.negocioService.getCervezas().subscribe( (datos) => {

        // Limpiamos datos del array de cervezas
        this.cervezas = [];
  
        datos.forEach(element => {
          let data = element.payload.doc.data();
          let identificador = element.payload.doc.id;
          this.cervezas.push({
            id:identificador,
            marca:data.marca,
            precio:data.precio,
            ibu:data.ibu,
            existencias:data.existencias
          });
        });
  
        this.dataSource = new MatTableDataSource(this.cervezas);
  
        // El spinner no se muestra
        this.mostrar = false;
      });
    }, 3000);

    
  }

}{}
