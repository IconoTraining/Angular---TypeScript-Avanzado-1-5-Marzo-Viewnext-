export interface Cerveza{
    id: number,
    marca: string,
    precio: number,
    ibu: number,
    existencias: boolean
}