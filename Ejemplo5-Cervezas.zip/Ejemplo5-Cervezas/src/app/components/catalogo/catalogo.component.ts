import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Cerveza } from 'src/app/models/Cerveza';
import { NegocioService } from 'src/app/services/negocio.service';

@Component({
  selector: 'app-catalogo',
  templateUrl: './catalogo.component.html',
  styleUrls: ['./catalogo.component.css']
})
export class CatalogoComponent implements OnInit {

  cervezas: Cerveza[] = [];

  nombreColumnas=['id','marca','precio','ibu','existencias'];
  dataSource = new MatTableDataSource(this.cervezas);

  constructor(private negocioService: NegocioService) { 
    this.cervezas = this.negocioService.getCervezas();
    this.dataSource = new MatTableDataSource(this.cervezas);
  }

  ngOnInit(): void {
  }

}
