import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { Cerveza } from '../models/Cerveza';

@Injectable({
  providedIn: 'root'
})
export class NegocioService {

  /*cervezas: Cerveza[] = [
    {id:1, marca:'Cruzcampo', precio:1.80, ibu:2, existencias:true},
    {id:2, marca:'Mahou', precio:1.50, ibu:3, existencias:true},
    {id:3, marca:'Estrella Galicia', precio:1.70, ibu:4, existencias:true},
    {id:4, marca:'Ambar', precio:1.90, ibu:2, existencias:true},
    {id:5, marca:'1906', precio:2.10, ibu:5, existencias:false},
    {id:6, marca:'Heineken', precio:2.30, ibu:1, existencias:true}
  ];*/

  constructor(private fireStore: AngularFirestore) { }

  public getCervezas(): any{
    return this.fireStore.collection('cervezas').snapshotChanges();
  }

  public buscarCerveza(id: number): any{
    return this.fireStore.collection('cervezas').doc(id.toString()).snapshotChanges();
  }

  public altaCerveza(datos: any): any{
    return this.fireStore.collection('cervezas').add(datos);
  }

  public eliminar(id: number): any{
    return this.fireStore.collection('cervezas').doc(id.toString()).delete();
  }

  public modificar(id: number, datos: any): any{
    return this.fireStore.collection('cervezas').doc(id.toString()).set(datos);
  }


}
