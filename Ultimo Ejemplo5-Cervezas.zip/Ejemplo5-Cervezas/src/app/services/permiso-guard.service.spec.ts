import { TestBed } from '@angular/core/testing';

import { PermisoGuardService } from './permiso-guard.service';

describe('PermisoGuardService', () => {
  let service: PermisoGuardService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PermisoGuardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
