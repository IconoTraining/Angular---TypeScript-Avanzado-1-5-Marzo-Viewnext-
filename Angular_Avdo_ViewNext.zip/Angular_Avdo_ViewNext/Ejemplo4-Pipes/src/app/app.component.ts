import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  texto: string = 'Bienvenido al curso de Angular';
  numero: number = 7788.55376568909865;
  porcentaje: number = 0.54567;
  fecha: Date = new Date();
  jsonObjeto = {nombre:'Juan',edad:36,telefonos:{tel1:917652389,tel2:616123456}};
}
