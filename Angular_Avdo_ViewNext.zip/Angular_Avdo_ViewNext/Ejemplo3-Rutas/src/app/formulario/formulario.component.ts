import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-formulario',
  templateUrl: './formulario.component.html',
  styleUrls: ['./formulario.component.css']
})
export class FormularioComponent implements OnInit {

  constructor(private ruta: ActivatedRoute) {
    console.log(this.ruta.snapshot.queryParams.nombre);
    console.log(this.ruta.snapshot.queryParams.apellido);
    console.log(this.ruta.snapshot.queryParams['nombre']);
    console.log(this.ruta.snapshot.queryParams['apellido']);
  }

  ngOnInit(): void {
  }

}
