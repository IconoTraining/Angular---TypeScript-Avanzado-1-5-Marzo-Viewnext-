import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { ContactoComponent } from './contacto/contacto.component';
import { FormularioComponent } from './formulario/formulario.component';
import { LoginComponent } from './login/login.component';

// Crear el array de rutas
const misRutas: Routes = [
  {path:'contacto/:nombre', component: ContactoComponent},
  {path:'formulario', component: FormularioComponent},
  {path:'login', component: LoginComponent}
];


@NgModule({
  declarations: [
    AppComponent,
    ContactoComponent,
    FormularioComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(misRutas)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
