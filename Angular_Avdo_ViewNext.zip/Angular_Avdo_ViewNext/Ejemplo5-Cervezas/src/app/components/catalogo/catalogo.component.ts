import { Component, OnInit } from '@angular/core';
import { Cerveza } from 'src/app/models/Cerveza';
import { NegocioService } from 'src/app/services/negocio.service';

@Component({
  selector: 'app-catalogo',
  templateUrl: './catalogo.component.html',
  styleUrls: ['./catalogo.component.css']
})
export class CatalogoComponent implements OnInit {

  cervezas: Cerveza[] = [];

  constructor(private negocioService: NegocioService) { 
    this.cervezas = this.negocioService.getCervezas();
  }

  ngOnInit(): void {
  }

}
