import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { NavBarComponent } from './components/nav-bar/nav-bar.component';
import { CatalogoComponent } from './components/catalogo/catalogo.component';
import { ContactoComponent } from './components/contacto/contacto.component';
import { DetalleComponent } from './components/detalle/detalle.component';
import { RouterModule, Routes } from '@angular/router';

import { AgmCoreModule } from '@agm/core';

const misRutas: Routes = [
  {path:'catalogo', component: CatalogoComponent},
  {path:'contacto', component: ContactoComponent},
  {path:'detalle/:codigo', component: DetalleComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    NavBarComponent,
    CatalogoComponent,
    ContactoComponent,
    DetalleComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(misRutas),
    AgmCoreModule.forRoot({
      apiKey: ''
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
