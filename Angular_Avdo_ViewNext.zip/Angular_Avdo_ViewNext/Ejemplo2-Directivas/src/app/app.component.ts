import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  alumnos: any = [
    {valoracion: 'alta', nombre: 'Juan', apellido: 'Lopez', nota: 7.5, repetidor: false},
    {valoracion: 'media', nombre: 'Maria', apellido: 'Sanchez', nota: 5.8, repetidor: false},
    {valoracion: 'baja', nombre: 'Elena', apellido: 'Arias', nota: 3.2, repetidor: true},
    {valoracion: 'media', nombre: 'Roberto', apellido: 'Rodriguez', nota: 6.4, repetidor: true},
    {valoracion: 'baja', nombre: 'Javier', apellido: 'Martin', nota: 4.1, repetidor: false},
    {valoracion: 'alta', nombre: 'Marta', apellido: 'Gonzalez', nota: 9.3, repetidor: false}
  ];
}
