import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title: string = 'Ejemplo1-Binding';
  nombre: string = 'Anabel';
  apellido: string = 'Vegas';

  habilitado: boolean = true;

  estilo = 'rojo';

  constructor(){
    setTimeout( () => {
      this.habilitado = false;
    }, 3000);
  }

  saludar(): void{
    alert("Bienvenido a Angular !!!!");
  }

  aplicarEstilo(): void{
    if(this.estilo == 'rojo'){
      this.estilo = 'verde';
    } else {
      this.estilo = 'rojo';
    }
  }
}
