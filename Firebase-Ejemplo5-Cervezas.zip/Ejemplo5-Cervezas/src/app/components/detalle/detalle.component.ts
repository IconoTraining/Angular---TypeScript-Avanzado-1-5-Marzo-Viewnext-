import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Cerveza } from 'src/app/models/Cerveza';
import { NegocioService } from 'src/app/services/negocio.service';

@Component({
  selector: 'app-detalle',
  templateUrl: './detalle.component.html',
  styleUrls: ['./detalle.component.css']
})
export class DetalleComponent implements OnInit {

  id: number = 0;
  cerveza: Cerveza = null;

  constructor(private ruta: ActivatedRoute, private negocioService: NegocioService) {
    this.id = this.ruta.snapshot.params.codigo;
    this.cerveza = null;

    this.negocioService.buscarCerveza(this.id).subscribe( (datos) => {     
        let data = datos.payload.data();
        let identificador = datos.payload.id;
        this.cerveza = {
          id:identificador,
          marca:data.marca,
          precio:data.precio,
          ibu:data.ibu,
          existencias:data.existencias
        };
    });

  }

  ngOnInit(): void {
  }

}
