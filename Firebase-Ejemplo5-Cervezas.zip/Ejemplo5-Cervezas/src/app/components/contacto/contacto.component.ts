import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html',
  styleUrls: ['./contacto.component.css']
})
export class ContactoComponent implements OnInit {
  lat:number = 40.4433622;
  lng:number = -3.7246336;
  zoom:number = 14;

  email = new FormControl('',[Validators.required]);
  mensaje = new FormControl('',[Validators.required]);

  constructor() { }

  ngOnInit(): void {
  }

  mostrarErrorEmail(){
    return this.email.hasError('required')?"El mail es obligatorio":"";
  }

  mostrarErrorMensaje(){
    return this.mensaje.hasError('required')?"El mensaje es obligatorio":"";
  }

}
