import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NegocioService } from 'src/app/services/negocio.service';

@Component({
  selector: 'app-formulario',
  templateUrl: './formulario.component.html',
  styleUrls: ['./formulario.component.css']
})
export class FormularioComponent implements OnInit {

  public newCervezaForm = new FormGroup({
    id: new FormControl('', Validators.required),
    marca: new FormControl('', Validators.minLength(3)),
    precio: new FormControl('',Validators.min(1)),
    ibu: new FormControl('',Validators.max(5)),
    existencias: new FormControl('',Validators.pattern('(false|true)'))
  });

  constructor(private negocioService: NegocioService) { }

  altaCerveza(){
    // Recuperar todos los datos del formulario
    let datos = {
      id:this.newCervezaForm.value.id,
      marca: this.newCervezaForm.value.marca,
      precio: this.newCervezaForm.value.precio,
      ibu: this.newCervezaForm.value.ibu,
      existencias: this.newCervezaForm.value.existencias
    }
    
    // Enviamos los datos al servicio
    this.negocioService.altaCerveza(datos)
      .then(() => {
        console.log("Cerveza insertada");

        // Limpiar el formulario
        this.newCervezaForm.reset();
      }, (error) =>{
        console.log(error);
      });
  }

  ngOnInit(): void {
  }

}
