import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-modal-envio',
  templateUrl: './modal-envio.component.html',
  styleUrls: ['./modal-envio.component.css']
})
export class ModalEnvioComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<ModalEnvioComponent>,
      @Inject(MAT_DIALOG_DATA) public data:any) { }

  cerrar(): void{
    this.dialogRef.close();
  }

  ngOnInit(): void {
  }

}
