import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-modal-recibo',
  templateUrl: './modal-recibo.component.html',
  styleUrls: ['./modal-recibo.component.css']
})
export class ModalReciboComponent implements OnInit {

  valoracion:'';

  constructor(public dialogRef: MatDialogRef<ModalReciboComponent>) { }

  cerrar(): void{
    this.dialogRef.close({
      valoracion: this.valoracion
    });
  }

  ngOnInit(): void {
  }

}
