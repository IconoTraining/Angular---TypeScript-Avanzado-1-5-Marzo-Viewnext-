import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-modal-envio-recibo',
  templateUrl: './modal-envio-recibo.component.html',
  styleUrls: ['./modal-envio-recibo.component.css']
})
export class ModalEnvioReciboComponent implements OnInit {

  edad = '';

  constructor(public dialogRef: MatDialogRef<ModalEnvioReciboComponent>,
    @Inject(MAT_DIALOG_DATA) public data:any) { }

  cerrar(): void{
    this.dialogRef.close({
      edad: this.edad,
      nombre: this.data.name
    });
  }

  ngOnInit(): void {
  }

}
