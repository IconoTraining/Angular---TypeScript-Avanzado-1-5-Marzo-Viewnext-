import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalEnvioReciboComponent } from './modal-envio-recibo.component';

describe('ModalEnvioReciboComponent', () => {
  let component: ModalEnvioReciboComponent;
  let fixture: ComponentFixture<ModalEnvioReciboComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ModalEnvioReciboComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalEnvioReciboComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
