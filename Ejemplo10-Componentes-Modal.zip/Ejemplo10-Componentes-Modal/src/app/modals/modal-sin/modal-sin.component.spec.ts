import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalSinComponent } from './modal-sin.component';

describe('ModalSinComponent', () => {
  let component: ModalSinComponent;
  let fixture: ComponentFixture<ModalSinComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ModalSinComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalSinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
