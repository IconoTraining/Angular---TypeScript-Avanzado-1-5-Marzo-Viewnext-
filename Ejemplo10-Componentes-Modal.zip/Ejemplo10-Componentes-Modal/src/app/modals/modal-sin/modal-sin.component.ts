import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-modal-sin',
  templateUrl: './modal-sin.component.html',
  styleUrls: ['./modal-sin.component.css']
})
export class ModalSinComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<ModalSinComponent>) { }

  cerrar(): void{
    this.dialogRef.close();
  }

  ngOnInit(): void {
  }

}
