import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';

import { FormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ModalSinComponent } from './modals/modal-sin/modal-sin.component';
import { ModalEnvioComponent } from './modals/modal-envio/modal-envio.component';
import { ModalReciboComponent } from './modals/modal-recibo/modal-recibo.component';
import { ModalEnvioReciboComponent } from './modals/modal-envio-recibo/modal-envio-recibo.component';

@NgModule({
  declarations: [
    AppComponent,
    ModalSinComponent,
    ModalEnvioComponent,
    ModalReciboComponent,
    ModalEnvioReciboComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
