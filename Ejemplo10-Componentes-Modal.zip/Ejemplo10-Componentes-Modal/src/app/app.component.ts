import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ModalEnvioReciboComponent } from './modals/modal-envio-recibo/modal-envio-recibo.component';
import { ModalEnvioComponent } from './modals/modal-envio/modal-envio.component';
import { ModalReciboComponent } from './modals/modal-recibo/modal-recibo.component';
import { ModalSinComponent } from './modals/modal-sin/modal-sin.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  nombre="Anabel";
  valoracion="";
  edad = '';

  constructor(public dialog: MatDialog){ }
  
  sinDatos(){
    this.dialog.open(ModalSinComponent,{
      width: '300px',
      disableClose: true // No se puede cerrar con esc o pinchando en el fondo
    });
  }

  envioDatos(){
    this.dialog.open(ModalEnvioComponent,{
      width: '300px',
      data: {name: this.nombre},
      disableClose: true
    });
  }

  reciboDatos(){
    let dialogRef = this.dialog.open(ModalReciboComponent,{
      width: '300px',
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      this.valoracion = result.valoracion;
    });
  }

  envioReciboDatos(){
    let dialogRef = this.dialog.open(ModalEnvioReciboComponent,{
      width: '300px',
      data: {name: this.nombre},
      disableClose: true  
    });

    dialogRef.afterClosed().subscribe(result => {
      this.edad = result.edad;
      this.nombre = result.nombre;
    });
  }
}
