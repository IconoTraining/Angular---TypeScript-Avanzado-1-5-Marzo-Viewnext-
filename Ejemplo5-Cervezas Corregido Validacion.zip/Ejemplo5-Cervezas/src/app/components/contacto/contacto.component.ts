import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html',
  styleUrls: ['./contacto.component.css']
})
export class ContactoComponent implements OnInit {
  lat:number = 40.4433622;
  lng:number = -3.7246336;
  zoom:number = 14;

  constructor() { }

  ngOnInit(): void {
  }

}
